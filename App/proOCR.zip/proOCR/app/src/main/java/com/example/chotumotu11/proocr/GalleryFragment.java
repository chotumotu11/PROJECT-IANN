package com.example.chotumotu11.proocr;

/*
        Author : Dipayan Deb
 */


import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.text.TextBlock;
import com.google.android.gms.vision.text.TextRecognizer;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;


public class GalleryFragment extends Fragment {

    List<File> file ;
    ImageView imageView ;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        file = new ArrayList();

    }

    /**
     * A placeholder fragment containing a simple view.
     */

    class ImageArray<T> extends ArrayAdapter<T> {

        private LayoutInflater inflater;
        private Context context;
        private int mresource;
        private T item;
        private ImageView image;
        ImageArray(Context context,int resource,int textviewresourceid,List<T> objects)
        {
            super(context,resource,textviewresourceid,objects);
            mresource =resource;
            this.context = context;
            inflater=LayoutInflater.from(context);
        }

        @Override
        public View getView(int position,View convertView,ViewGroup parent){

            View view;

            if(convertView==null)
            {
                view =inflater.inflate(mresource,parent,false);
            }
            else
            {
                view=convertView;
            }




            image = (ImageView) view;
            Picasso.with(context).load((File)getItem(position)).resize(200,200).into(image);


            return image;

        }


    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View frameLayout = inflater.inflate(R.layout.fragment_gallery, container, false);
        //imageView = (ImageView) frameLayout.findViewById(R.id.imageView);
        String[]  colums_to_retrive = {MediaStore.Images.Media._ID,MediaStore.MediaColumns.DATA};
        Cursor cursor = getActivity().getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,null,null,null,null);

        cursor.moveToFirst();
        String name="";
        String capture ="";
        File name1 = new File("");
        for(int i=0;i<cursor.getCount();i++){

            name = cursor.getString(cursor.getColumnIndex(MediaStore.MediaColumns.DATA));
            cursor.moveToNext();
            name1 = new File(name);
            file.add(name1);

        }

        final ImageArray<File> boo = new ImageArray<File>(getActivity(),R.layout.image_view,R.id.Image_id,file);
        GridView gridView = (GridView) frameLayout.findViewById(R.id.gridview);
        gridView.setAdapter(boo);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {

                File foo = boo.getItem(position);
                Bitmap bit = null;
                try {
                    bit = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(),Uri.fromFile(foo));
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Frame frame = new Frame.Builder().setBitmap(bit).build();
                TextRecognizer textRecognizer = new TextRecognizer.Builder(getContext()).build();
                String coppa = "";
                SparseArray<TextBlock> texts = textRecognizer.detect(frame);
                for (int i = 0; i < texts.size(); ++i) {
                    TextBlock text = texts.valueAt(i);
                    if (text != null && text.getValue() != null) {
                        coppa = coppa+" "+text.getValue();
                    }

                }

                Toast.makeText(getActivity(), "" + coppa,
                        Toast.LENGTH_SHORT).show();

                Fragment te = new Text1();
                Bundle arguments = new Bundle();
                arguments.putString("Dipayan",coppa);
                te.setArguments(arguments);
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.dispfrag,te).commit();


            }
        });

        return frameLayout;
    }




}
