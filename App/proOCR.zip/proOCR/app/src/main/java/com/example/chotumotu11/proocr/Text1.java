package com.example.chotumotu11.proocr;

/*
    Author : Dipayan Deb
 */

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Locale;


public class Text1 extends Fragment implements View.OnClickListener {


    public Text1() {
        // Required empty public constructor
    }

    Bundle arguments;
    EditText textView;
    private TextToSpeech tts;
    Button button2 ;
    String mytext;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        arguments = getArguments();
        // TODO: Set up the Text To Speech engine.
        TextToSpeech.OnInitListener listener =
                new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(final int status) {
                        if (status == TextToSpeech.SUCCESS) {
                            Log.d("TTS", "Text to speech engine started successfully.");
                            tts.setLanguage(Locale.US);
                        } else {
                            Log.d("TTS", "Error starting the text to speech engine.");
                        }
                    }
                };
        tts = new TextToSpeech(getContext(), listener);



    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_text, container, false);
        textView = (EditText) view.findViewById(R.id.DispOCR);
        mytext = arguments.getString("Dipayan");
        textView.setText(mytext);

        button2 = (Button) view.findViewById(R.id.button2);
         //       tts.speak(mytext, TextToSpeech.QUEUE_ADD, null, "DEFAULT");
        button2.setOnClickListener(this);
        return view;
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        tts.shutdown();

    }


    @Override
    public void onClick(View v) {
        tts.speak(mytext, TextToSpeech.QUEUE_ADD, null, "DEFAULT");
    }
}
