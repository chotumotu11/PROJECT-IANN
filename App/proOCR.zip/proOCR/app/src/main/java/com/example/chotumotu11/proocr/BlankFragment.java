package com.example.chotumotu11.proocr;

/*
    Author : Dipayan Deb
*/

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.example.chotumotu11.proocr.ui.camera.CameraSource;
import com.example.chotumotu11.proocr.ui.camera.CameraSourcePreview;
import com.example.chotumotu11.proocr.ui.camera.GraphicOverlay;
import com.google.android.gms.vision.text.TextBlock;
import com.google.android.gms.vision.text.TextRecognizer;

import java.io.IOException;
import java.util.Locale;



// Blankfragment is the camera fragment.

public class BlankFragment extends Fragment  {

    private static final String TAG = "OcrCaptureActivity";
    private final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 1;
    // Intent request code to handle updating play services if needed.
    private static final int RC_HANDLE_GMS = 9001;

    // Permission request codes need to be < 256
    private static final int RC_HANDLE_CAMERA_PERM = 2;

    // Constants used to pass extra data in the intent
    public static final String AutoFocus = "AutoFocus";
    public static final String UseFlash = "UseFlash";
    public static final String TextBlockObject = "String";

    private CameraSource mCameraSource;
    private CameraSourcePreview mPreview;
    private GraphicOverlay<OcrGraphic> mGraphicOverlay;

    // Helper objects for detecting taps and pinches.
    private ScaleGestureDetector scaleGestureDetector;
    private GestureDetector gestureDetector;
    private Button button1;
    public FragmentManager fragm;

    // A TextToSpeech engine for speaking a String value.

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



    }

    boolean autoFocus;
    boolean useFlash;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final FrameLayout frameLayout = (FrameLayout) inflater.inflate(R.layout.fragment, container, false);
        // Get the preview that displays live feed from the camera and the graphics overlays that display that show the text overhead.
        mPreview = (CameraSourcePreview) frameLayout.findViewById(R.id.preview);
        mGraphicOverlay = (GraphicOverlay<OcrGraphic>) frameLayout.findViewById(R.id.graphicOverlay);
        fragm = getFragmentManager();
        // Set good defaults for capturing text.
        autoFocus = true;
        useFlash = false;
        button1 = (Button) frameLayout.findViewById(R.id.button);
        createCameraSource(autoFocus,useFlash);








        return frameLayout;

    }

    @SuppressLint("InlinedApi")
    private void createCameraSource(boolean autoFocus, boolean useFlash) {
        Context context = getContext();

        // TODO: Create the TextRecognizer
        TextRecognizer textRecognizer = new TextRecognizer.Builder(context).build();
        // TODO: Set the TextRecognizer's Processor.
        textRecognizer.setProcessor(new OcrDetectorProcessor(mGraphicOverlay,button1,fragm));
        // TODO: Check if the TextRecognizer is operational.
        if(!textRecognizer.isOperational()) {
            Log.w(TAG,"Detector Dependencies are still not available");
            // Check for low storage.
            IntentFilter intentFilter = new IntentFilter(Intent.ACTION_DEVICE_STORAGE_LOW);
            boolean boo_storage_check = getContext().registerReceiver(null,intentFilter) !=null;

            if(boo_storage_check){
                Toast.makeText(getContext(),R.string.low_storage_error,Toast.LENGTH_LONG).show();
                Log.w(TAG,getString(R.string.low_storage_error));
            }
        }
        // TODO: Create the mCameraSource using the TextRecognizer.
        mCameraSource = new CameraSource.Builder(getContext(),textRecognizer).setFacing(CameraSource.CAMERA_FACING_BACK).setRequestedPreviewSize(1280,1024).setRequestedFps(15.0f).setFlashMode(useFlash ? Camera.Parameters.FLASH_MODE_TORCH : null).setFocusMode(autoFocus ? Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE : null).build();


    }

    private void startCameraSource() throws SecurityException {
        // check that the device has play services available.
        int code = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(
                getContext());
        if (code != ConnectionResult.SUCCESS) {
            Dialog dlg =
                    GoogleApiAvailability.getInstance().getErrorDialog(getActivity(), code, RC_HANDLE_GMS);
            dlg.show();
        }

        if (mCameraSource != null) {
            try {
                mPreview.start(mCameraSource, mGraphicOverlay);
            } catch (IOException e) {
                Log.e(TAG, "Unable to start camera source.", e);
                mCameraSource.release();
                mCameraSource = null;
            }
        }


    }



    /**
     * Restarts the camera.
     */
    @Override
    public void onResume() {
        super.onResume();
        startCameraSource();
    }

    /**
     * Stops the camera.
     */
    @Override
    public void onPause() {
        super.onPause();
        if (mPreview != null) {
            mPreview.stop();
        }
    }

    /**
     * Releases the resources associated with the camera source, the associated detectors, and the
     * rest of the processing pipeline.
     */
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mPreview != null) {
            mPreview.release();
        }
    }













}
