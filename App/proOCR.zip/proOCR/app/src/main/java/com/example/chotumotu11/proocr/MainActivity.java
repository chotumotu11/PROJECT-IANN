/*
     Author : Dipayan Deb
     Purpose : This is the main activity of the project. This activity is responsible for loading all other fragments properly.
     The  fragments in the app
     1. BlankFragment - This fragment houses the cameraView and Overlay that is put over the camera so that the green Detected writings can
        be displayed. The camera feed is passed to the textRecognizer which is responsible for detecting all Text. When Text is detected the
        OcrDecterProcessor is called . This piece of code is responsible for extracting the text from the detected data and putting it on the
        Screen
        Also once the convert Button is Clicked the Text is passed on to the next activity(Text1) as a string.

     2. GalleryFragment - This uses a curser and getContentResolver along with EXTERNAL STORAGE URI for Pictures to gather all the Images present
        in the phone. Then it uses a GridView along with Picasa Photo Library to Insert Images into the GridView. Once a Image is clicked. That
        Image is passed to the TextRecognzer . Which Recognizes the Image and calls The Text1 fargment to display the text.

     3. CreditsFragment - This Fragment contains the names and Photos of all the people that were responsible for developing this project.
 */

package com.example.chotumotu11.proocr;

import android.Manifest;
import android.app.Fragment;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;
import android.content.Intent;


public class MainActivity extends AppCompatActivity {



    private TextView mTextMessage;
    FragmentManager fragmentManager = getSupportFragmentManager();
    private final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 1;
    private final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE=2;
    FragmentTransaction fragmentTransaction;
    BlankFragment fragment;
    boolean canstart_app=false;
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_dashboard:
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    BlankFragment fragment = new BlankFragment();
                    fragmentTransaction.replace(R.id.dispfrag, fragment);
                    fragmentTransaction.commit();
                    return true;

                case R.id.navigation_notifications:
                    //mTextMessage.setText(R.string.title_photogallery);
                    FragmentTransaction fragmentTransaction1 = fragmentManager.beginTransaction();
                    GalleryFragment fragment1 = new GalleryFragment();
                    fragmentTransaction1.replace(R.id.dispfrag, fragment1);
                    fragmentTransaction1.commit();
                    return true;
                case R.id.navigation_credits:
                    FragmentTransaction fragmentTransaction2 = fragmentManager.beginTransaction();
                    CreditsFragment fragment2 = new CreditsFragment();
                    fragmentTransaction2.replace(R.id.dispfrag, fragment2);
                    fragmentTransaction2.commit();
                    return true;
            }
            return false;
        }

    };

    @Override
    protected void onResume() {
        super.onResume();
        if(canstart_app){
            startapp();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.


            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        }


        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.CAMERA)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.


            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.CAMERA},
                        MY_PERMISSIONS_REQUEST_READ_CONTACTS);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        }else{

           startapp();
        }





    }


    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_READ_CONTACTS: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.

                    canstart_app=true;

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    finish();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    public void startapp(){
        fragmentTransaction = fragmentManager.beginTransaction();
        fragment = new BlankFragment();
        fragmentTransaction.add(R.id.dispfrag, fragment);
        fragmentTransaction.commit();

    }


}
