/*
    Author : Dipayan Deb
 */
package com.example.chotumotu11.proocr;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.widget.Button;

import com.example.chotumotu11.proocr.ui.camera.GraphicOverlay;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.text.TextBlock;

/**
 * A very simple Processor which gets detected TextBlocks and adds them to the overlay
 * as OcrGraphics.
 * TODO: Make this implement Detector.Processor<TextBlock> and add text to the GraphicOverlay
 */


public class OcrDetectorProcessor implements Detector.Processor<TextBlock>, View.OnClickListener{

    private GraphicOverlay<OcrGraphic> mGraphicOverlay;
    private SparseArray<TextBlock> items;
    private FragmentManager context;
    OcrDetectorProcessor(GraphicOverlay<OcrGraphic> ocrGraphicOverlay,Button button1,FragmentManager fragm) {
        mGraphicOverlay = ocrGraphicOverlay;
        button1.setOnClickListener(this);
        this.context = fragm;
    }

    @Override
    public void release() {

    }

    @Override
    public void receiveDetections(Detector.Detections<TextBlock> detections) {
        mGraphicOverlay.clear();
        items = detections.getDetectedItems();
        for(int i=0;i<items.size();++i){
            TextBlock item = items.valueAt(i);
            if(item!=null && item.getValue()!=null){
                Log.d("Processor","Text Detected! "+ item.getValue());
            }
            OcrGraphic graphic = new OcrGraphic(mGraphicOverlay,item);
            mGraphicOverlay.add(graphic);
        }

    }


    @Override
    public void onClick(View v) {
        String mytext = "";
        if(v.getId()==R.id.button){
            if(items!=null){
                for(int i=0;i<items.size();++i){
                    TextBlock item = items.valueAt(i);
                    if(item!=null && item.getValue()!=null){
                        mytext=mytext+item.getValue();
                    }
                }
                Log.v("yoyo",mytext);
                Text1 te = new Text1();
                Bundle arguments = new Bundle();
                arguments.putString("Dipayan",mytext);
                te.setArguments(arguments);
                FragmentTransaction ft = context.beginTransaction();
                ft.replace(R.id.dispfrag, te);
                ft.commit();

            }
            else{
                Log.v("Button1","I am getting no string you idiot");
            }
        }
    }



}
